const InventoryManager = require('../inventoryManager');

describe('Inventory Manager', () => {
  let inventory;

  beforeEach(() => {
    inventory = new InventoryManager();
  });

  test('add product', () => {
    inventory.addProduct({
      productID: 1,
      name: 'Phone',
      category: 'Electronics',
      price: 500,
      stock: 10
    });

    expect(inventory.listAllProducts().length).toBe(1);
  });

  test('get product by ID', () => {
    inventory.addProduct({
      productID: 2,
      name: 'Laptop',
      category: 'Electronics',
      price: 1000,
      stock: 5
    });

    const product = inventory.getProductById(2);
    expect(product.name).toBe('Laptop');
  });

  test('update product', () => {
    inventory.addProduct({
      productID: 3,
      name: 'Mouse',
      category: 'Accessories',
      price: 20,
      stock: 50
    });

    inventory.updateProduct(3, { price: 25 });
    expect(inventory.getProductById(3).price).toBe(25);
  });

  test('delete product', () => {
    inventory.addProduct({
      productID: 4,
      name: 'Keyboard',
      category: 'Accessories',
      price: 40,
      stock: 20
    });

    inventory.deleteProduct(4);
    expect(inventory.getProductById(4)).toBeNull();
  });
});
