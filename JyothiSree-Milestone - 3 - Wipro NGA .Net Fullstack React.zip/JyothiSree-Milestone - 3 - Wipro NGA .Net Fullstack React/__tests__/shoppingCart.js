const ShoppingCart = require('../shoppingCart');

describe('ShoppingCart Service', () => {
  let cart;

  beforeEach(() => {
    cart = new ShoppingCart();
  });

  test('add item to cart', () => {
    cart.addItem('Book', 100, 2);
    expect(cart.items.length).toBe(1);
  });

  test('remove item by name', () => {
    cart.addItem('Pen', 10, 2);
    cart.addItem('Pen', 10, 1);
    cart.removeItem('Pen');
    expect(cart.items.length).toBe(0);
  });

  test('calculate total price', () => {
    cart.addItem('A', 50, 2);
    cart.addItem('B', 100, 1);
    expect(cart.calculateTotalPrice()).toBe(200);
  });

  test('apply discount code', () => {
    cart.addItem('Item', 100, 1);
    cart.applyDiscountCode('SAVE10');
    const amount = cart.checkout(0);
    expect(amount).toBe(90);
  });

  test('checkout clears cart', () => {
    cart.addItem('Item', 100, 1);
    cart.checkout(0.1);
    expect(cart.items.length).toBe(0);
  });
});
