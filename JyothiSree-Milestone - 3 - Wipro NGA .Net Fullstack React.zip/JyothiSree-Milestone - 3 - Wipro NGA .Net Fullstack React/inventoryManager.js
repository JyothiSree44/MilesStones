class InventoryManager {
  constructor() {
    this.inventory = [];
  }

  addProduct(product) {
    const exists = this.inventory.find(
      p => p.productID === product.productID
    );

    if (exists) {
      throw new Error("Product already exists");
    }

    this.inventory.push({ ...product });
  }

  getProductById(productID) {
    return this.inventory.find(
      p => p.productID === productID
    ) || null;
  }

  updateProduct(productID, updatedFields) {
    const product = this.inventory.find(
      p => p.productID === productID
    );

    if (!product) {
      throw new Error("Product not found");
    }

    Object.assign(product, updatedFields);
  }

  deleteProduct(productID) {
    const index = this.inventory.findIndex(
      p => p.productID === productID
    );

    if (index === -1) {
      throw new Error("Product not found");
    }

    this.inventory.splice(index, 1);
  }

  listAllProducts() {
    return this.inventory;
  }
}

module.exports = InventoryManager;
