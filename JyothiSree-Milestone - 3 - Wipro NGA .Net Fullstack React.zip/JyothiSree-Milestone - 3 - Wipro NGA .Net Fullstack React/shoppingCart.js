class ShoppingCart {
  constructor() {
    this.items = [];
    this.discountPercentage = 0;
  }

  addItem(name, price, quantity) {
    this.items.push({ name, price, quantity });
  }

  removeItem(name) {
    this.items = this.items.filter(item => item.name !== name);
  }

  calculateTotalPrice() {
    return this.items.reduce(
      (total, item) => total + item.price * item.quantity,
      0
    );
  }

  applyDiscountCode(code) {
    const discounts = {
      SAVE10: 0.1,
      SAVE20: 0.2,
      SAVE30: 0.3
    };

    this.discountPercentage = discounts[code] || 0;
  }

  calculateTax(taxRate) {
    return this.calculateTotalPrice() * taxRate;
  }

  checkout(taxRate) {
    const total = this.calculateTotalPrice();
    const tax = total * taxRate;
    const discount = total * this.discountPercentage;

    const finalAmount = total + tax - discount;

    this.items = [];
    this.discountPercentage = 0;

    return finalAmount;
  }
}

module.exports = ShoppingCart;
